package Classes;

import java.util.ArrayList;

public class Grafo<Tipo> {

    private ArrayList<Vertice<Tipo>> vertices;
    private ArrayList<Aresta<Tipo>> arestas;

    public Grafo() {
        this.vertices = new ArrayList<Vertice<Tipo>>();
        this.arestas = new ArrayList<Aresta<Tipo>>();
    }

    public void adicionarVertice(Tipo dado) {
        Vertice<Tipo> novoVertice = new Vertice<Tipo>(dado);
        this.vertices.add(novoVertice);
        
    }

    public void adicionarAresta(Double peso, Tipo dadoInicio, Tipo dadoFim) {
        Vertice<Tipo> inicio = this.getVertice(dadoInicio);
        Vertice<Tipo> fim = this.getVertice(dadoFim);
        Aresta<Tipo> aresta = new Aresta<>(peso, inicio, fim);
        inicio.adicionarArestaSaida(aresta);
        fim.adicionarArestaEntrada(aresta);
        this.arestas.add(aresta);
        
        
    }

    // Criar método para retornar o Vértice<Tipo> caso encontre na lista
    
    public Vertice<Tipo> getVertice(Tipo dado){

        Vertice<Tipo> vertice = null;

        for (int i = 0; i < this.vertices.size(); i++) { // por ser um arraylist, tem um método size()
            if(this.vertices.get(i).getDado().equals(dado)){
                vertice = this.vertices.get(i);
                break;
            }
        }

        return vertice;

    }

    
    
}
