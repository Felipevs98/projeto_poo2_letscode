import Classes.Grafo;

public class App {
    public static void main(String[] args) throws Exception {
        Grafo<String> grafo = new Grafo<>();
        grafo.adicionarVertice("BSB");
        grafo.adicionarVertice("SSA");
        grafo.adicionarVertice("SDU");
        grafo.adicionarVertice("VCP");
        grafo.adicionarVertice("REC");
        grafo.adicionarVertice("NAT");
        grafo.adicionarVertice("GRU");
        grafo.adicionarVertice("POA");

        grafo.adicionarAresta(1.0, "BSB", "SSA");
        grafo.adicionarAresta(1.0, "SDU", "SSA");
        grafo.adicionarAresta(1.0, "VCP", "SSA");
        grafo.adicionarAresta(1.0, "SSA", "REC");
        grafo.adicionarAresta(1.0, "GRU", "REC");
        grafo.adicionarAresta(1.0, "SSA", "NAT");
        grafo.adicionarAresta(1.0, "BSB", "NAT");
        grafo.adicionarAresta(1.0, "GRU", "NAT");
        grafo.adicionarAresta(1.0, "BSB", "GRU");
        grafo.adicionarAresta(1.0, "GRU", "BSB");
        grafo.adicionarAresta(1.0, "POA", "BSB");
        grafo.adicionarAresta(1.0, "GRU", "POA");
    }
}
