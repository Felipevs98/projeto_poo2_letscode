interface NumericValidator {
    boolean IsValid(int x);
}

class IsEven implements NumericValidator {

    @Override
    public boolean IsValid(int x) {
        // TODO Auto-generated method stub
        return x%2 == 0;
    }

}

class IsPrimeValidator implements NumericValidator{

    @Override
    public boolean IsValid(int x) {
        
        for (int i = x/2; i > 1; i--) {
            if(x%i == 0){
                return false;
            }
        }
        return true;
    }

}

public class App {
    public static void main(String[] args) throws Exception {
        
        NumericValidator validIsPrime = new IsPrimeValidator();
        NumericValidator validIsEven = new IsEven();

        // usando lambda
        NumericValidator validIsOdd = (int x) -> (x%2 == 1); // depois do sinal de igualdade, está criando
                                                             // um valor que recebe inteiro e deve retornar
                                                             // boolean

                                                             // Só é possível escrever quando é interface
                                                             // Similar a arrow function em javascript

        NumericValidator validMultiple3and5 = (x) ->         // expressões lambdas só implementam interfaces
                                                             // método abstrato porque precisa referenciar
                                                             // a tipagem dos dados.
                                                             // Interface com um único método abstrato = 
                                                             // interface funcional.
                                                            {
                                                               return x%15 == 0; 
                                                            };

        // printValidNumber(12, validIsEven);
        // printValidNumber(12, validIsPrime);
        printValidNumber(12, validIsOdd);
        printValidNumber(15, validMultiple3and5);
    }

    public static void printValidNumber(int x, NumericValidator validator){
        if(validator.IsValid(x)){
            System.out.println(x);
        }
    }
}
